import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface CounterState {
  count: number;
  max: number;
  min: number;
}

@Injectable({
  providedIn: 'root'
})
export class CounterService {
  private readonly initialState: CounterState = {
    count: 0,
    max: 100,
    min: 0
  };

  private stateSubject = new BehaviorSubject<CounterState>(this.initialState);
  public state$ = this.stateSubject.asObservable();

  constructor() { }

  getCurrentState(): CounterState {
    return this.stateSubject.value;
  }

  increment(): void {
    const currentState = this.getCurrentState();
    if (currentState.count < currentState.max) {
      this.updateState({
        ...currentState,
        count: currentState.count + 1
      });
    }
  }

  decrement(): void {
    const currentState = this.getCurrentState();
    if (currentState.count > currentState.min) {
      this.updateState({
        ...currentState,
        count: currentState.count - 1
      });
    }
  }

  reset(): void {
    const currentState = this.getCurrentState();
    this.updateState({
      ...currentState,
      count: Math.max(this.initialState.count, currentState.min)
    });
  }

  setMax(max: number): void {
    const currentState = this.getCurrentState();
    if (max >= currentState.min) {
      this.updateState({
        ...currentState,
        max,
        count: Math.min(currentState.count, max)
      });
    }
  }

  setMin(min: number): void {
    const currentState = this.getCurrentState();
    if (min <= currentState.max) {
      this.updateState({
        ...currentState,
        min,
        count: Math.max(currentState.count, min)
      });
    }
  }

  private updateState(newState: CounterState): void {
    this.stateSubject.next(newState);
  }
}