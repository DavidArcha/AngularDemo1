import { TestBed } from '@angular/core/testing';
import { CounterService, CounterState } from './counter.service';
import { setupCustomMatchers } from '../testing';

describe('CounterService', () => {
  let service: CounterService;

  beforeEach(() => {
    setupCustomMatchers();
    TestBed.configureTestingModule({});
    service = TestBed.inject(CounterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('initial state', () => {
    it('should have correct initial state', () => {
      const state = service.getCurrentState();
      expect(state).toEqual({
        count: 0,
        max: 100,
        min: 0
      });
    });

    it('should emit initial state through observable', (done) => {
      service.state$.subscribe(state => {
        expect(state.count).toBe(0);
        expect(state.max).toBe(100);
        expect(state.min).toBe(0);
        done();
      });
    });
  });

  describe('increment functionality', () => {
    it('should increment count by 1', () => {
      service.increment();
      
      const state = service.getCurrentState();
      expect(state.count).toBe(1);
    });

    it('should emit updated state when incremented', (done) => {
      let callCount = 0;
      service.state$.subscribe(state => {
        callCount++;
        if (callCount === 2) { // Skip initial emission
          expect(state.count).toBe(1);
          done();
        }
      });
      
      service.increment();
    });

    it('should not increment beyond max value', () => {
      // Set count to max - 1
      for (let i = 0; i < 100; i++) {
        service.increment();
      }
      
      const beforeMax = service.getCurrentState();
      expect(beforeMax.count).toBe(100);
      
      // Try to increment beyond max
      service.increment();
      
      const afterMax = service.getCurrentState();
      expect(afterMax.count).toBe(100);
    });

    it('should respect custom max when incrementing', () => {
      service.setMax(5);
      
      // Increment to max
      for (let i = 0; i < 10; i++) {
        service.increment();
      }
      
      const state = service.getCurrentState();
      expect(state.count).toBe(5);
    });
  });

  describe('decrement functionality', () => {
    beforeEach(() => {
      // Set count to 5 for decrement tests
      for (let i = 0; i < 5; i++) {
        service.increment();
      }
    });

    it('should decrement count by 1', () => {
      service.decrement();
      
      const state = service.getCurrentState();
      expect(state.count).toBe(4);
    });

    it('should emit updated state when decremented', (done) => {
      let initialEmissionReceived = false;
      service.state$.subscribe(state => {
        if (!initialEmissionReceived) {
          initialEmissionReceived = true;
          return; // Skip initial emission with count = 5
        }
        expect(state.count).toBe(4);
        done();
      });
      
      service.decrement();
    });

    it('should not decrement below min value', () => {
      // Reset to start from 0
      service.reset();
      
      const beforeMin = service.getCurrentState();
      expect(beforeMin.count).toBe(0);
      
      // Try to decrement below min
      service.decrement();
      
      const afterMin = service.getCurrentState();
      expect(afterMin.count).toBe(0);
    });

    it('should respect custom min when decrementing', () => {
      service.setMin(3);
      // Count is now adjusted to 5 (current count was 5, min is 3, so count stays 5)
      // Reset to 0, but then adjust based on new min
      service.reset(); // This goes to initial value 0, but min is 3, so it should be 3
      
      const stateAfterSetMin = service.getCurrentState();
      expect(stateAfterSetMin.count).toBe(3); // Should be adjusted to min
      
      // Try to decrement below min
      service.decrement();
      
      const state = service.getCurrentState();
      expect(state.count).toBe(3);
    });
  });

  describe('reset functionality', () => {
    it('should reset count to 0', () => {
      // Increment first
      service.increment();
      service.increment();
      expect(service.getCurrentState().count).toBe(2);
      
      service.reset();
      
      const state = service.getCurrentState();
      expect(state.count).toBe(0);
    });

    it('should emit updated state when reset', (done) => {
      let callCount = 0;
      service.state$.subscribe(state => {
        callCount++;
        if (callCount === 4) { // After initial + 2 increments + 1 reset
          expect(state.count).toBe(0);
          done();
        }
      });
      
      service.increment();
      service.increment();
      service.reset();
    });
  });

  describe('setMax functionality', () => {
    it('should update max value', () => {
      service.setMax(50);
      
      const state = service.getCurrentState();
      expect(state.max).toBe(50);
    });

    it('should adjust count if it exceeds new max', () => {
      // Increment to 10
      for (let i = 0; i < 10; i++) {
        service.increment();
      }
      
      // Set max to 5
      service.setMax(5);
      
      const state = service.getCurrentState();
      expect(state.count).toBe(5);
      expect(state.max).toBe(5);
    });

    it('should not set max below current min', () => {
      service.setMin(10);
      const stateAfterSetMin = service.getCurrentState();
      
      service.setMax(5); // Should be rejected because 5 < 10
      
      const finalState = service.getCurrentState();
      expect(finalState.max).toBe(stateAfterSetMin.max); // Should remain unchanged
    });

    it('should emit updated state when max is changed', (done) => {
      let callCount = 0;
      service.state$.subscribe(state => {
        callCount++;
        if (callCount === 2) { // Skip initial emission
          expect(state.max).toBe(50);
          done();
        }
      });
      
      service.setMax(50);
    });
  });

  describe('setMin functionality', () => {
    it('should update min value', () => {
      service.setMin(5);
      
      const state = service.getCurrentState();
      expect(state.min).toBe(5);
    });

    it('should adjust count if it falls below new min', () => {
      // Start from 0
      expect(service.getCurrentState().count).toBe(0);
      
      // Set min to 5
      service.setMin(5);
      
      const state = service.getCurrentState();
      expect(state.count).toBe(5);
      expect(state.min).toBe(5);
    });

    it('should not set min above current max', () => {
      service.setMax(50);
      const initialState = service.getCurrentState();
      
      service.setMin(60); // Should be rejected
      
      const finalState = service.getCurrentState();
      expect(finalState.min).toBe(initialState.min);
    });

    it('should emit updated state when min is changed', (done) => {
      let callCount = 0;
      service.state$.subscribe(state => {
        callCount++;
        if (callCount === 2) { // Skip initial emission
          expect(state.min).toBe(5);
          done();
        }
      });
      
      service.setMin(5);
    });
  });

  describe('complex scenarios', () => {
    it('should handle multiple operations correctly', () => {
      // Set custom bounds
      service.setMin(2);
      service.setMax(8);
      
      // Count is now at least 2 (min), increment to middle
      let currentCount = service.getCurrentState().count;
      const targetCount = 5;
      for (let i = currentCount; i < targetCount; i++) {
        service.increment();
      }
      expect(service.getCurrentState().count).toBe(targetCount);
      
      // Reset should respect the current min
      service.reset();
      expect(service.getCurrentState().count).toBe(2); // Should be max(0, 2) = 2
      
      // But if we set min after reset
      service.setMin(3);
      expect(service.getCurrentState().count).toBe(3);
    });

    it('should maintain state consistency', () => {
      service.setMax(10);
      service.setMin(2);
      
      // Increment to max
      for (let i = 0; i < 15; i++) {
        service.increment();
      }
      
      const state = service.getCurrentState();
      expect(state.count).toBeLessThanOrEqual(state.max);
      expect(state.count).toBeGreaterThanOrEqual(state.min);
      expect(state.min).toBeLessThanOrEqual(state.max);
    });
  });

  describe('observable behavior', () => {
    it('should emit state changes in order', (done) => {
      const emissions: number[] = [];
      
      service.state$.subscribe(state => {
        emissions.push(state.count);
        
        if (emissions.length === 4) {
          expect(emissions).toEqual([0, 1, 2, 1]); // initial, +1, +1, -1
          done();
        }
      });
      
      service.increment(); // 0 -> 1
      service.increment(); // 1 -> 2  
      service.decrement(); // 2 -> 1
    });

    it('should allow multiple subscribers', () => {
      let subscriber1Count = 0;
      let subscriber2Count = 0;
      
      service.state$.subscribe(() => subscriber1Count++);
      service.state$.subscribe(() => subscriber2Count++);
      
      service.increment();
      service.increment();
      
      expect(subscriber1Count).toBe(3); // initial + 2 changes
      expect(subscriber2Count).toBe(3); // initial + 2 changes
    });
  });
});