import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement, Type } from '@angular/core';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

/**
 * Utility functions for Angular testing
 */
export class TestUtils {
  
  /**
   * Creates a component fixture with basic testing module setup
   */
  static async createComponent<T>(
    component: Type<T>,
    imports: any[] = [],
    declarations: any[] = [],
    providers: any[] = []
  ): Promise<ComponentFixture<T>> {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        ...imports
      ],
      declarations: [component, ...declarations],
      providers: [...providers]
    }).compileComponents();

    const fixture = TestBed.createComponent(component);
    fixture.detectChanges();
    return fixture;
  }

  /**
   * Helper to get element by CSS selector
   */
  static getElement<T>(
    fixture: ComponentFixture<T>,
    selector: string
  ): HTMLElement | null {
    return fixture.nativeElement.querySelector(selector);
  }

  /**
   * Helper to get all elements by CSS selector
   */
  static getAllElements<T>(
    fixture: ComponentFixture<T>,
    selector: string
  ): NodeListOf<HTMLElement> {
    return fixture.nativeElement.querySelectorAll(selector);
  }

  /**
   * Helper to get DebugElement by CSS selector
   */
  static getDebugElement<T>(
    fixture: ComponentFixture<T>,
    selector: string
  ): DebugElement | null {
    return fixture.debugElement.query(By.css(selector));
  }

  /**
   * Helper to get all DebugElements by CSS selector
   */
  static getAllDebugElements<T>(
    fixture: ComponentFixture<T>,
    selector: string
  ): DebugElement[] {
    return fixture.debugElement.queryAll(By.css(selector));
  }

  /**
   * Helper to click an element
   */
  static clickElement<T>(
    fixture: ComponentFixture<T>,
    selector: string
  ): void {
    const element = this.getElement(fixture, selector);
    if (element) {
      element.click();
      fixture.detectChanges();
    }
  }

  /**
   * Helper to set input value
   */
  static setInputValue<T>(
    fixture: ComponentFixture<T>,
    selector: string,
    value: string
  ): void {
    const input = this.getElement(fixture, selector) as HTMLInputElement;
    if (input) {
      input.value = value;
      input.dispatchEvent(new Event('input'));
      fixture.detectChanges();
    }
  }

  /**
   * Helper to wait for async operations
   */
  static async waitForAsync(): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, 0));
  }
}

/**
 * Custom matchers for better test assertions
 */
export const customMatchers: jasmine.CustomMatcherFactories = {
  toHaveClass: () => {
    return {
      compare: (actual: HTMLElement, expected: string) => {
        const pass = actual.classList.contains(expected);
        return {
          pass,
          message: pass
            ? `Expected ${actual} not to have class '${expected}'`
            : `Expected ${actual} to have class '${expected}'`
        };
      }
    };
  },

  toBeVisible: () => {
    return {
      compare: (actual: HTMLElement) => {
        const pass = actual.offsetParent !== null;
        return {
          pass,
          message: pass
            ? `Expected ${actual} not to be visible`
            : `Expected ${actual} to be visible`
        };
      }
    };
  }
};

/**
 * Setup function to add custom matchers
 */
export function setupCustomMatchers(): void {
  jasmine.addMatchers(customMatchers);
}

declare global {
  namespace jasmine {
    interface Matchers<T> {
      toHaveClass(expected: string): boolean;
      toBeVisible(): boolean;
    }
  }
}