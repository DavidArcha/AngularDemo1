import { of, throwError, Subject, BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';

/**
 * Mock utilities for testing Angular services and HTTP requests
 */
export class MockUtils {
  
  /**
   * Creates a spy object with methods that return observables
   */
  static createSpyObj(baseName: string, methodNames: string[]): jasmine.SpyObj<any> {
    const obj: any = {};
    
    methodNames.forEach(method => {
      obj[method] = jasmine.createSpy(`${baseName}.${method}`).and.returnValue(of({}));
    });
    
    return obj;
  }

  /**
   * Creates a mock service with observable methods
   */
  static createMockService<T>(methods: (keyof T)[]): jasmine.SpyObj<T> {
    const mockService = jasmine.createSpyObj('MockService', methods as string[]);
    
    // Default all methods to return empty observables
    methods.forEach(method => {
      mockService[method].and.returnValue(of({}));
    });
    
    return mockService;
  }

  /**
   * Creates a mock HTTP response
   */
  static createMockHttpResponse(data: any, status = 200): any {
    return {
      status,
      statusText: status === 200 ? 'OK' : 'Error',
      body: data,
      headers: new Map(),
      url: 'http://localhost/test'
    };
  }

  /**
   * Creates a mock error response
   */
  static createMockErrorResponse(error: string, status = 500): any {
    return throwError(() => ({
      status,
      statusText: 'Error',
      error: { message: error },
      message: error
    }));
  }

  /**
   * Helper to create a subject for testing reactive components
   */
  static createSubject<T>(initialValue?: T): Subject<T> | BehaviorSubject<T> {
    return initialValue !== undefined 
      ? new BehaviorSubject<T>(initialValue)
      : new Subject<T>();
  }
}

/**
 * Common mock data for testing
 */
export class MockData {
  
  static readonly sampleUser = {
    id: 1,
    name: 'Test User',
    email: 'test@example.com',
    role: 'user'
  };

  static readonly sampleUsers = [
    { id: 1, name: 'John Doe', email: 'john@example.com', role: 'admin' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'user' },
    { id: 3, name: 'Bob Johnson', email: 'bob@example.com', role: 'user' }
  ];

  static readonly sampleApiResponse = {
    success: true,
    data: MockData.sampleUser,
    message: 'Operation completed successfully'
  };

  static readonly sampleErrorResponse = {
    success: false,
    error: 'Something went wrong',
    message: 'An error occurred'
  };
}

/**
 * Router testing utilities
 */
export class RouterTestUtils {
  
  /**
   * Creates a mock activated route with parameters
   */
  static createMockActivatedRoute(params: any = {}, queryParams: any = {}): any {
    return {
      params: of(params),
      queryParams: of(queryParams),
      snapshot: {
        params,
        queryParams,
        paramMap: {
          get: (key: string) => params[key]
        },
        queryParamMap: {
          get: (key: string) => queryParams[key]
        }
      }
    };
  }

  /**
   * Creates a mock router with navigation spy
   */
  static createMockRouter(): jasmine.SpyObj<any> {
    return jasmine.createSpyObj('Router', ['navigate', 'navigateByUrl']);
  }
}

/**
 * Form testing utilities
 */
export class FormTestUtils {
  
  /**
   * Helper to get form control errors as string array
   */
  static getControlErrors(control: any): string[] {
    if (!control || !control.errors) {
      return [];
    }
    
    return Object.keys(control.errors);
  }

  /**
   * Helper to check if form control has specific error
   */
  static hasControlError(control: any, errorKey: string): boolean {
    return control && control.errors && control.errors[errorKey];
  }

  /**
   * Helper to trigger form validation
   */
  static triggerFormValidation(form: any): void {
    form.markAllAsTouched();
    form.updateValueAndValidity();
  }
}