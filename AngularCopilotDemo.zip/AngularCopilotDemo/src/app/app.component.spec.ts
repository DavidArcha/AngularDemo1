import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { TestUtils, setupCustomMatchers } from './testing';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async () => {
    setupCustomMatchers();
    
    await TestBed.configureTestingModule({
      imports: [
        RouterModule.forRoot([])
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'AngularCopilotDemo'`, () => {
    expect(component.title).toEqual('AngularCopilotDemo');
  });

  it('should render title', () => {
    const titleElement = TestUtils.getElement(fixture, 'h1');
    expect(titleElement?.textContent).toContain('Hello, AngularCopilotDemo');
  });

  it('should have router outlet', () => {
    const routerOutlet = TestUtils.getElement(fixture, 'router-outlet');
    expect(routerOutlet).toBeTruthy();
  });
});
