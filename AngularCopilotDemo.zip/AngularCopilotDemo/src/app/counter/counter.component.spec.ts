import { ComponentFixture } from '@angular/core/testing';
import { CounterComponent } from './counter.component';
import { TestUtils, setupCustomMatchers } from '../testing';

describe('CounterComponent', () => {
  let component: CounterComponent;
  let fixture: ComponentFixture<CounterComponent>;

  beforeEach(async () => {
    setupCustomMatchers();
    fixture = await TestUtils.createComponent(CounterComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with default values', () => {
    expect(component.count).toBe(0);
    expect(component.initialValue).toBe(0);
    expect(component.max).toBe(10);
  });

  it('should initialize with custom initial value', () => {
    component.initialValue = 5;
    component.ngOnInit();
    expect(component.count).toBe(5);
  });

  it('should display the current count', () => {
    component.count = 3;
    fixture.detectChanges();
    
    const countDisplay = TestUtils.getElement(fixture, 'h2');
    expect(countDisplay?.textContent).toContain('Counter: 3');
  });

  describe('increment functionality', () => {
    it('should increment count when increment button is clicked', () => {
      const initialCount = component.count;
      
      TestUtils.clickElement(fixture, '.increment-btn');
      
      expect(component.count).toBe(initialCount + 1);
    });

    it('should emit countChange event when incremented', () => {
      spyOn(component.countChange, 'emit');
      
      component.increment();
      
      expect(component.countChange.emit).toHaveBeenCalledWith(1);
    });

    it('should not increment beyond max value', () => {
      component.count = 10;
      component.max = 10;
      
      component.increment();
      
      expect(component.count).toBe(10);
    });

    it('should disable increment button when at max', () => {
      component.count = 10;
      component.max = 10;
      fixture.detectChanges();
      
      const incrementBtn = TestUtils.getElement(fixture, '.increment-btn') as HTMLButtonElement;
      expect(incrementBtn.disabled).toBe(true);
    });
  });

  describe('decrement functionality', () => {
    beforeEach(() => {
      component.count = 5;
      fixture.detectChanges();
    });

    it('should decrement count when decrement button is clicked', () => {
      TestUtils.clickElement(fixture, '.decrement-btn');
      
      expect(component.count).toBe(4);
    });

    it('should emit countChange event when decremented', () => {
      spyOn(component.countChange, 'emit');
      
      component.decrement();
      
      expect(component.countChange.emit).toHaveBeenCalledWith(4);
    });

    it('should not decrement below zero', () => {
      component.count = 0;
      
      component.decrement();
      
      expect(component.count).toBe(0);
    });

    it('should disable decrement button when at zero', () => {
      component.count = 0;
      fixture.detectChanges();
      
      const decrementBtn = TestUtils.getElement(fixture, '.decrement-btn') as HTMLButtonElement;
      expect(decrementBtn.disabled).toBe(true);
    });
  });

  describe('reset functionality', () => {
    it('should reset count to initial value', () => {
      component.initialValue = 3;
      component.count = 7;
      
      TestUtils.clickElement(fixture, '.reset-btn');
      
      expect(component.count).toBe(3);
    });

    it('should emit countChange event when reset', () => {
      spyOn(component.countChange, 'emit');
      component.initialValue = 2;
      
      component.reset();
      
      expect(component.countChange.emit).toHaveBeenCalledWith(2);
    });
  });

  describe('component integration', () => {
    it('should have all required buttons rendered', () => {
      const incrementBtn = TestUtils.getElement(fixture, '.increment-btn');
      const decrementBtn = TestUtils.getElement(fixture, '.decrement-btn');
      const resetBtn = TestUtils.getElement(fixture, '.reset-btn');
      
      expect(incrementBtn).toBeTruthy();
      expect(decrementBtn).toBeTruthy();
      expect(resetBtn).toBeTruthy();
    });

    it('should update display when count changes', () => {
      TestUtils.clickElement(fixture, '.increment-btn');
      TestUtils.clickElement(fixture, '.increment-btn');
      
      const countDisplay = TestUtils.getElement(fixture, 'h2');
      expect(countDisplay?.textContent).toContain('Counter: 2');
    });

    it('should handle multiple operations correctly', () => {
      // Start at 0, increment to 3
      TestUtils.clickElement(fixture, '.increment-btn');
      TestUtils.clickElement(fixture, '.increment-btn');
      TestUtils.clickElement(fixture, '.increment-btn');
      expect(component.count).toBe(3);
      
      // Decrement to 1
      TestUtils.clickElement(fixture, '.decrement-btn');
      TestUtils.clickElement(fixture, '.decrement-btn');
      expect(component.count).toBe(1);
      
      // Reset to initial (0)
      TestUtils.clickElement(fixture, '.reset-btn');
      expect(component.count).toBe(0);
    });
  });

  describe('custom inputs', () => {
    it('should work with custom max value', async () => {
      component.max = 5;
      component.count = 4;
      
      component.increment();
      expect(component.count).toBe(5);
      
      component.increment(); // Should not increment beyond max
      expect(component.count).toBe(5);
    });

    it('should respect custom initial value on reset', () => {
      component.initialValue = 7;
      component.count = 3;
      
      component.reset();
      
      expect(component.count).toBe(7);
    });
  });

  describe('getCurrentCount method', () => {
    it('should return current count value', () => {
      component.count = 42;
      
      expect(component.getCurrentCount()).toBe(42);
    });
  });
});