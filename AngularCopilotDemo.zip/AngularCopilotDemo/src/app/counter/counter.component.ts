import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-counter',
  template: `
    <div class="counter">
      <h2>Counter: {{ count }}</h2>
      <button class="increment-btn" (click)="increment()" [disabled]="count >= max">+</button>
      <button class="decrement-btn" (click)="decrement()" [disabled]="count <= 0">-</button>
      <button class="reset-btn" (click)="reset()">Reset</button>
    </div>
  `,
  styles: [`
    .counter {
      padding: 20px;
      text-align: center;
    }
    
    .counter button {
      margin: 0 5px;
      padding: 10px 15px;
      font-size: 16px;
    }
    
    .counter button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `],
  standalone: false
})
export class CounterComponent {
  @Input() initialValue = 0;
  @Input() max = 10;
  @Output() countChange = new EventEmitter<number>();

  count = 0;

  ngOnInit(): void {
    this.count = this.initialValue;
  }

  increment(): void {
    if (this.count < this.max) {
      this.count++;
      this.countChange.emit(this.count);
    }
  }

  decrement(): void {
    if (this.count > 0) {
      this.count--;
      this.countChange.emit(this.count);
    }
  }

  reset(): void {
    this.count = this.initialValue;
    this.countChange.emit(this.count);
  }

  getCurrentCount(): number {
    return this.count;
  }
}