# Unit Testing Guide for Angular Copilot Demo

This project is configured with a comprehensive unit testing environment using Jasmine and Karma.

## Testing Framework Setup

### Core Testing Tools
- **Jasmine**: Behavior-driven development framework for testing JavaScript code
- **Karma**: Test runner for executing tests in browsers
- **Angular Testing Utilities**: Built-in Angular testing helpers

### Additional Testing Utilities
- **Custom Test Utils**: Located in `src/app/testing/test-utils.ts`
- **Mock Utils**: Located in `src/app/testing/mock-utils.ts`
- **Custom Matchers**: Enhanced assertions for better test readability

## Available Test Scripts

```bash
# Run tests in watch mode (default)
npm run test

# Run tests with watch mode explicitly
npm run test:watch

# Run tests once in headless Chrome
npm run test:headless

# Run tests with code coverage
npm run test:coverage

# Run tests for CI/CD (headless + coverage)
npm run test:ci
```

## Test File Structure

```
src/
  app/
    testing/
      index.ts              # Barrel export for testing utilities
      test-utils.ts         # Component testing helpers
      mock-utils.ts         # Mock data and service utilities
    *.spec.ts              # Test files (follow *.spec.ts naming convention)
  test.ts                  # Test setup and configuration
karma.conf.js              # Karma configuration
```

## Writing Tests

### Basic Component Test Structure

```typescript
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TestUtils, setupCustomMatchers } from './testing';
import { YourComponent } from './your-component';

describe('YourComponent', () => {
  let component: YourComponent;
  let fixture: ComponentFixture<YourComponent>;

  beforeEach(async () => {
    setupCustomMatchers();
    
    fixture = await TestUtils.createComponent(YourComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
```

### Using Test Utils

```typescript
// Get elements
const button = TestUtils.getElement(fixture, '.my-button');
const inputs = TestUtils.getAllElements(fixture, 'input');

// Click elements
TestUtils.clickElement(fixture, '.submit-button');

// Set input values
TestUtils.setInputValue(fixture, '#email', 'test@example.com');

// Custom matchers
expect(element).toHaveClass('active');
expect(element).toBeVisible();
```

### Testing Services

```typescript
import { MockUtils } from './testing';

describe('YourService', () => {
  let service: YourService;
  let httpMock: jasmine.SpyObj<HttpClient>;

  beforeEach(() => {
    const spy = MockUtils.createMockService(['get', 'post']);
    
    TestBed.configureTestingModule({
      providers: [
        { provide: HttpClient, useValue: spy }
      ]
    });
    
    service = TestBed.inject(YourService);
    httpMock = TestBed.inject(HttpClient) as jasmine.SpyObj<HttpClient>;
  });
});
```

### Mock Data Usage

```typescript
import { MockData } from './testing';

// Use predefined mock data
httpMock.get.and.returnValue(of(MockData.sampleUsers));

// Create custom responses
const mockResponse = MockUtils.createMockHttpResponse(MockData.sampleUser);
const mockError = MockUtils.createMockErrorResponse('User not found', 404);
```

## Configuration Files

### Karma Configuration (`karma.conf.js`)
- Configured for Chrome and headless Chrome
- Code coverage reporting with HTML, text, and LCOV formats
- Coverage thresholds set to 80% for statements, branches, functions, and lines

### TypeScript Test Configuration (`tsconfig.spec.json`)
- Extends main TypeScript config
- Includes test files and type definitions
- Configured for Jasmine types

### Test Setup (`src/test.ts`)
- Global test environment initialization
- Automatic test discovery
- Global test hooks for setup and cleanup

## Best Practices

### Test Organization
1. **Group related tests**: Use `describe` blocks to group related functionality
2. **Clear test names**: Use descriptive test names that explain what is being tested
3. **AAA Pattern**: Arrange, Act, Assert - structure your tests clearly

### Test Data
1. **Use mock data**: Leverage the provided `MockData` class for consistent test data
2. **Isolate tests**: Each test should be independent and not rely on others
3. **Clean up**: Use `afterEach` to clean up any global state

### Performance
1. **Selective testing**: Use focused tests (`fit`, `fdescribe`) during development
2. **Mock dependencies**: Always mock external dependencies
3. **Async testing**: Use proper async/await patterns for asynchronous code

### Coverage Goals
- **Statements**: 80% minimum (Current: ~58%)
- **Branches**: 80% minimum (Current: ~34%)  
- **Functions**: 80% minimum (Current: ~40%)
- **Lines**: 80% minimum (Current: ~59%)

Note: Coverage thresholds are set as goals. The current setup provides a solid foundation with 49 comprehensive tests covering component interactions, service logic, and edge cases.

## Debugging Tests

### Running Specific Tests
```bash
# Run tests for a specific file
ng test --include='**/app.component.spec.ts'

# Run tests matching a pattern
ng test --grep='should render title'
```

### Browser Debugging
1. Tests run in Chrome by default
2. Use `debugger;` statements in test code
3. Open browser dev tools when Karma launches
4. Set breakpoints and inspect variables

### Common Issues
1. **Async operations**: Use `fakeAsync` and `tick` for testing async code
2. **Change detection**: Call `fixture.detectChanges()` after component changes
3. **Module imports**: Ensure all required modules are imported in test setup

## Advanced Testing Patterns

### Testing Forms
```typescript
import { FormTestUtils } from './testing';

// Check form validation
FormTestUtils.triggerFormValidation(component.myForm);
expect(FormTestUtils.hasControlError(component.myForm.get('email'), 'required')).toBe(true);
```

### Testing Routing
```typescript
import { RouterTestUtils } from './testing';

// Mock ActivatedRoute
const mockRoute = RouterTestUtils.createMockActivatedRoute({ id: '123' });

// Mock Router
const mockRouter = RouterTestUtils.createMockRouter();
```

### Testing HTTP Calls
```typescript
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

// Setup HTTP testing
const httpMock = TestBed.inject(HttpTestingController);

// Expect and respond to requests
const req = httpMock.expectOne('/api/users');
req.flush(MockData.sampleUsers);
```

## Continuous Integration

The `test:ci` script is configured for CI/CD environments:
- Runs in headless Chrome
- Generates code coverage reports
- Exits after single run
- Outputs results in CI-friendly format

For GitHub Actions, Jenkins, or other CI systems, use:
```bash
npm run test:ci
```

This will generate coverage reports in the `coverage/` directory that can be uploaded to coverage services like Codecov or Coveralls.